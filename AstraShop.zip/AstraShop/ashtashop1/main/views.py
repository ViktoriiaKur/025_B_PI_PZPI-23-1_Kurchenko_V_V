from django.http import HttpResponse
from django.shortcuts import render

from goods.models import Categories

def index(request):
    context: dict[str,str]={
        'title':'Astra - Головна',
        'content': "Магазин квітів Astra",
    }    
    return render(request, 'main/index.html', context)

def about(request):
    context: dict[str,str]={
        'title':'Astra - О нас',
        'content': "О нас",
        'text_on_page':'ПЗПІпз-23-1. Виторія Курченко, бакалаврат ЦПО'
        
    }
    
    return render(request, 'main/about.html', context)