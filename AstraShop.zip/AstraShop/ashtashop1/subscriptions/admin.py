from django.contrib import admin
from subscriptions.models import SubscriptionType, Subscription, DeliveryDate

@admin.register(SubscriptionType)
class SubscriptionTypeAdmin(admin.ModelAdmin):
    list_display = ["name", "max_dates", "price_per_month"]
    list_editable = ["max_dates", "price_per_month"]
    search_fields = ["name"]
    ordering = ["price_per_month"]

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ["user", "type", "start_date", "is_active"]
    list_editable = ["is_active"]
    list_filter = ["is_active", "type"]
    search_fields = ["user__username"]
    autocomplete_fields = ["user", "type"]
    date_hierarchy = "start_date"
    ordering = ["-start_date"]

@admin.register(DeliveryDate)
class DeliveryDateAdmin(admin.ModelAdmin):
    list_display = ["subscription", "delivery_date","user_phone_number"]
    list_filter = ["delivery_date"]
    search_fields = ["subscription__user__username"]
    autocomplete_fields = ["subscription"]
    ordering = ["delivery_date"]

    @admin.display(description='Телефон користувача')
    def user_phone_number(self, obj):
        return obj.subscription.user.phone_number or '—'



# from django.contrib import admin

# from subscriptions.models import DeliveryDate, Subscription, SubscriptionType

# # Register your models here.
# admin.site.register(Subscription)
# admin.site.register(SubscriptionType)
# admin.site.register(DeliveryDate)