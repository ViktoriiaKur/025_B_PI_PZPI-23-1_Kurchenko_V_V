# subscriptions/forms.py
from django import forms
from .models import Subscription, DeliveryDate

class SubscriptionForm(forms.ModelForm):
    class Meta:
        model = Subscription
        fields = ['type']

class DeliveryDatesForm(forms.Form):
    def __init__(self, *args, **kwargs):
        max_dates = kwargs.pop('max_dates', 3)  # <-- Витягуємо max_dates перед super()
        super().__init__(*args, **kwargs)

        for i in range(max_dates):
            self.fields[f'date_{i}'] = forms.DateField(
                widget=forms.SelectDateWidget,
                required=False,
                label=f'Дата {i + 1}'
            )
    # delivery_dates = forms.DateField(widget=forms.SelectDateWidget, required=True)
    # Примітка: у реальній реалізації потрібна динамічна генерація полів за кількістю доступних дат
