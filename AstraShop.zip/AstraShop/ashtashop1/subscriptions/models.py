# subscriptions/models.py
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class SubscriptionType(models.Model):
    name = models.CharField(max_length=50)
    max_dates = models.PositiveIntegerField()
    price_per_month = models.DecimalField(max_digits=6, decimal_places=2)

    class Meta:
        verbose_name='Тип підписки'
        verbose_name_plural='Типи підписок'
        ordering=("id",)

    def __str__(self):
        return self.name

class Subscription(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    type = models.ForeignKey(SubscriptionType, on_delete=models.PROTECT)
    start_date = models.DateField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name='Підписки користувачів'
        verbose_name_plural='Підписки'
        ordering=("id",)

    def __str__(self):
        return f"{self.user.username} - {self.type.name}"

class DeliveryDate(models.Model):
    subscription = models.ForeignKey(Subscription, on_delete=models.CASCADE, related_name="delivery_dates")
    delivery_date = models.DateField()

    class Meta:
        verbose_name='Дати підписок'
        verbose_name_plural='Дати підписок'
        ordering=("id",)

    def __str__(self):
        return f"{self.subscription.user.username} - {self.delivery_date}"

