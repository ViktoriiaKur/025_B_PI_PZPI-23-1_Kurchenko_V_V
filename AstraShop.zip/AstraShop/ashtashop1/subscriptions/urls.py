from django.urls import path
from subscriptions import views

app_name = 'subscriptions'

urlpatterns = [
    path('', views.choose_subscription, name='choose_subscription'),
    path('set_dates/<int:subscription_id>/', views.set_delivery_dates, name='set_delivery_dates'),
    path('my/', views.my_subscription, name='my_subscription'),
]
