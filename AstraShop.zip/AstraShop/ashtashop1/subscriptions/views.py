# subscriptions/views.py
from django.shortcuts import render, redirect
from .models import SubscriptionType, Subscription, DeliveryDate
from .forms import SubscriptionForm, DeliveryDatesForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages

@login_required
def choose_subscription(request):

    if request.method == 'POST':
        form = SubscriptionForm(request.POST)
        if form.is_valid():
            subscription = form.save(commit=False)
            subscription.user = request.user
            subscription.save()
            return redirect('subscriptions:set_delivery_dates', subscription_id=subscription.id)
    else:
        form = SubscriptionForm()

    context={
        'title':'AstraShop - Авторизація',
        'form':form,
    }
    return render(request, 'subscriptions/choose_plan.html',context)


@login_required
def set_delivery_dates(request, subscription_id):
    subscription = Subscription.objects.get(id=subscription_id, user=request.user)
    max_dates = subscription.type.max_dates

    # Отримати вже збережені дати
    existing_dates = subscription.delivery_dates.values_list('delivery_date', flat=True)

    if request.method == 'POST':
        dates = request.POST.getlist('delivery_dates')
        if len(dates) <= max_dates:
            # Очистити старі дати перед збереженням нових
            subscription.delivery_dates.all().delete()

            for date in dates:
                if date:
                    DeliveryDate.objects.create(subscription=subscription, delivery_date=date)
            messages.success(request, 'Підписка оновлена успішно!')
            return redirect('subscriptions:my_subscription')
        else:
            messages.error(request, f'Максимальна кількість дат: {max_dates}')
    
    context = {
        'subscription': subscription,
        'max_dates': max_dates,
        'date_fields': range(max_dates),
        'existing_dates': list(existing_dates),  # передаємо список дат
    }
    return render(request, 'subscriptions/set_dates.html', context)


# @login_required
# def set_delivery_dates(request, subscription_id):
#     subscription = Subscription.objects.get(id=subscription_id, user=request.user)
#     max_dates = subscription.type.max_dates

#     if request.method == 'POST':
#         dates = request.POST.getlist('delivery_dates')
#         if len(dates) <= max_dates:
#             for date in dates:
#                 DeliveryDate.objects.create(subscription=subscription, delivery_date=date)
#             messages.success(request, 'Підписка оформлена успішно!')
#             return redirect('subscriptions:my_subscription')
#         else:
#             messages.error(request, f'Максимальна кількість дат: {max_dates}')
    
#     context = {
#         'subscription': subscription,
#         'max_dates': max_dates,
#         'date_fields': range(max_dates),
#     }
#     return render(request, 'subscriptions/set_dates.html', context)


# @login_required
# def set_delivery_dates(request, subscription_id):
#     subscription = Subscription.objects.get(id=subscription_id, user=request.user)
#     max_dates = subscription.type.max_dates

#     if request.method == 'POST':
#         form = DeliveryDatesForm(request.POST, max_dates=max_dates)
#         if form.is_valid():
#             # Зібрати всі заповнені дати
#             dates = [
#                 form.cleaned_data[key]
#                 for key in form.fields
#                 if form.cleaned_data.get(key)
#             ]
#             if len(dates) <= max_dates:
#                 for date in dates:
#                     DeliveryDate.objects.create(subscription=subscription, delivery_date=date)
#                 messages.success(request, 'Підписка оформлена успішно!')
#                 return redirect('subscriptions:my_subscription')
#             else:
#                 messages.error(request, f'Максимальна кількість дат: {max_dates}')
#     else:
#         form = DeliveryDatesForm(max_dates=max_dates)

#     context = {
#         'subscription': subscription,
#         'max_dates': max_dates,
#         'date_fields': range(max_dates),
#         'form': form,
#     }
#     return render(request, 'subscriptions/set_dates.html', context)


# def set_delivery_dates(request, subscription_id):
#     subscription = Subscription.objects.get(id=subscription_id, user=request.user)
#     max_dates = subscription.type.max_dates
    
    
    
#     if request.method == 'POST':
#         dates = request.POST.getlist('delivery_dates')
#         if len(dates) <= max_dates:
#             for date in dates:
#                 DeliveryDate.objects.create(subscription=subscription, delivery_date=date)
#             messages.success(request, 'Підписка оформлена успішно!')
#             return redirect('subscriptions:my_subscription')
#         else:
#             messages.error(request, f'Максимальна кількість дат: {max_dates}')
#     form = DeliveryDatesForm()
#     context={
#         'subscription': subscription, 
#         'max_dates': max_dates,
#         'form':form
#     }
#     return render(request, 'subscriptions/set_dates.html', context)




@login_required
def my_subscription(request):
    subscription = Subscription.objects.filter(user=request.user, is_active=True).first()
    countdate= subscription.delivery_dates.count()
    subscription_id=subscription.id
    monthprice=subscription.type.price_per_month

    if subscription:
        delivery_dates=subscription.delivery_dates.all()

    context={
        'subscription': subscription,
        'countdate':countdate,
        'alldates':delivery_dates,
        'subscription_id':subscription_id,
        'price':monthprice
    }
    return render(request, 'subscriptions/my_subscription.html', context)